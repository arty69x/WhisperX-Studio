import React, { useState } from 'react';
import { LandingPage } from './LandingPage';
import { SentimentDashboard } from '@/components/SentimentDashboard';
import { CanvasStudio } from '@/components/CanvasStudio';
import { motion, AnimatePresence } from 'framer-motion';
import { LayoutDashboard, Brain, Cpu, LogOut } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function Home() {
  const [view, setView] = useState<'landing' | 'dashboard' | 'workspace'>('landing');

  return (
    <div className="min-h-screen bg-black">
      <AnimatePresence mode="wait">
        {view === 'landing' ? (
          <motion.div
            key="landing"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.5, ease: "circOut" }}
          >
            <LandingPage onGetStarted={() => setView('dashboard')} />
          </motion.div>
        ) : (
          <motion.div
            key="content"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col h-screen"
          >
            {/* Global Context Switcher */}
            <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 p-2 bg-black/80 backdrop-blur-2xl border border-white/10 rounded-full shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
              <NavButton 
                active={view === 'dashboard'} 
                onClick={() => setView('dashboard')} 
                icon={LayoutDashboard} 
                label="Intelligence" 
              />
              <NavButton 
                active={view === 'workspace'} 
                onClick={() => setView('workspace')} 
                icon={Cpu} 
                label="Visual Forge" 
              />
              <div className="w-[1px] h-6 bg-white/10 mx-2" />
              <button 
                onClick={() => setView('landing')}
                className="p-3 text-zinc-500 hover:text-rose-500 transition-colors"
                title="Reset Session"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>

            <main className="flex-1 overflow-auto">
              {view === 'dashboard' ? (
                <SentimentDashboard />
              ) : (
                <CanvasStudio />
              )}
            </main>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

const NavButton: React.FC<{ active: boolean; onClick: () => void; icon: any; label: string }> = ({ active, onClick, icon: Icon, label }) => (
  <button
    onClick={onClick}
    className={cn(
      "flex items-center gap-3 px-6 py-3 rounded-full transition-all duration-500 group relative overflow-hidden",
      active ? "bg-white text-black" : "text-zinc-500 hover:text-white"
    )}
  >
    {active && (
      <motion.div 
        layoutId="active-nav-bg"
        className="absolute inset-0 bg-white"
        transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
      />
    )}
    <Icon className={cn("w-4 h-4 relative z-10 transition-transform duration-500", active && "group-hover:scale-110")} />
    <span className="text-xs font-bold uppercase tracking-widest relative z-10">{label}</span>
  </button>
);
