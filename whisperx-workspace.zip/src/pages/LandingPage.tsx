import React from 'react';
import { motion } from 'framer-motion';
import { 
  Zap, 
  Shield, 
  Globe, 
  ArrowRight, 
  Layers, 
  Cpu, 
  Infinity 
} from 'lucide-react';

interface LandingPageProps {
  onGetStarted: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onGetStarted }) => {
  return (
    <div className="min-h-screen bg-black text-white selection:bg-violet-500/30 overflow-x-hidden">
      {/* Background Ambience */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-violet-600/10 blur-[150px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-emerald-600/5 blur-[150px] rounded-full" />
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay" />
      </div>

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 px-8 py-6 flex items-center justify-between backdrop-blur-md bg-black/20 border-b border-white/5">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-white flex items-center justify-center rounded-lg">
            <div className="w-4 h-4 bg-black rounded-[2px] rotate-45" />
          </div>
          <span className="text-xl font-medium tracking-tighter">WhisperX <span className="text-zinc-500">Nexus</span></span>
        </div>
        <div className="hidden md:flex items-center gap-8 text-sm font-medium text-zinc-400">
          <a href="#" className="hover:text-white transition-colors">Workspace</a>
          <a href="#" className="hover:text-white transition-colors">Intelligence</a>
          <a href="#" className="hover:text-white transition-colors">Ecosystem</a>
        </div>
        <button 
          onClick={onGetStarted}
          className="bg-white text-black px-6 py-2 rounded-full text-sm font-bold hover:bg-zinc-200 transition-all active:scale-95"
        >
          Compute Now
        </button>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-48 pb-32 px-8 flex flex-col items-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6 inline-flex items-center gap-2 px-4 py-1 rounded-full border border-white/10 bg-white/5 text-[10px] font-mono tracking-[0.2em] uppercase text-violet-400"
        >
          <div className="w-1.5 h-1.5 rounded-full bg-violet-400 animate-pulse" />
          Neural Synthesis v4.0 is Live
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-6xl md:text-8xl lg:text-9xl font-sans font-medium tracking-tight mb-8 leading-[0.9]"
        >
          Forge <span className="text-zinc-600">Thought</span><br />
          into <span className="italic font-serif">Reality</span>.
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="max-w-2xl text-lg md:text-xl text-zinc-500 mb-12 leading-relaxed"
        >
          The ultimate workspace for synthesis. Analyze complex sentiment streams 
          and transform them into procedural visual architecture through a unified 
          intelligence interface.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
          className="flex flex-col sm:flex-row gap-4"
        >
          <button 
            onClick={onGetStarted}
            className="px-10 py-5 bg-white text-black font-bold rounded-2xl flex items-center gap-3 hover:bg-zinc-200 transition-all group relative overflow-hidden"
          >
            Start Refining
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
          <button className="px-10 py-5 bg-white/5 border border-white/10 text-white font-bold rounded-2xl hover:bg-white/10 transition-all">
            Documentation
          </button>
        </motion.div>
      </section>

      {/* Feature Grid */}
      <section className="px-8 py-32 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <FeatureCard 
            icon={Zap}
            title="Instant Sensation"
            description="Process millions of data points in milliseconds with our custom neural inference engine."
            delay={0.4}
          />
          <FeatureCard 
            icon={Globe}
            title="Global Resonance"
            description="Map sentiment patterns across geographic and digital planes with extreme precision."
            delay={0.5}
          />
          <FeatureCard 
            icon={Shield}
            title="Encrypted Forge"
            description="Your creative and intellectual assets are protected by enterprise-grade cryptographic silos."
            delay={0.6}
          />
        </div>
      </section>

      {/* Visual Teaser */}
      <section className="px-8 py-32 relative overflow-hidden">
        <div className="max-w-6xl mx-auto bg-white/5 border border-white/10 rounded-[40px] aspect-[16/9] relative overflow-hidden group">
          <div className="absolute inset-0 bg-gradient-to-br from-violet-500/10 to-transparent opacity-50" />
          <div className="absolute inset-0 flex items-center justify-center">
             <div className="relative">
                <div className="absolute inset-0 bg-violet-500 blur-3xl opacity-20 animate-pulse" />
                <Infinity className="w-32 h-32 text-white relative z-10" />
             </div>
          </div>
          <div className="absolute bottom-8 left-8 right-8 flex items-end justify-between">
            <div>
              <p className="text-zinc-500 font-mono text-xs uppercase tracking-widest mb-2">Workspace Preview</p>
              <h3 className="text-2xl font-medium tracking-tight">Procedural Generation Interface</h3>
            </div>
            <div className="px-4 py-1.5 rounded-full border border-white/20 bg-black/40 backdrop-blur-md text-[10px] font-mono">
              STABLE_RELEASE_04
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-8 py-20 border-t border-white/5 text-center">
        <div className="flex items-center justify-center gap-2 mb-8 opacity-50 grayscale">
          <Cpu className="w-6 h-6" />
          <Layers className="w-6 h-6" />
          <Infinity className="w-6 h-6" />
        </div>
        <p className="text-zinc-600 text-sm font-mono tracking-widest uppercase">
          &copy; 2024 WhisperX Nexus Omega. All Rights Reserved.
        </p>
      </footer>
    </div>
  );
};

const FeatureCard: React.FC<{ icon: any; title: string; description: string; delay: number }> = ({ icon: Icon, title, description, delay }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ delay }}
    className="group p-8 bg-white/5 border border-white/5 rounded-3xl hover:bg-white/[0.07] hover:border-white/10 transition-all"
  >
    <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-violet-500/20 transition-colors">
      <Icon className="w-6 h-6 text-zinc-400 group-hover:text-violet-400 transition-colors" />
    </div>
    <h3 className="text-xl font-medium mb-3 tracking-tight">{title}</h3>
    <p className="text-zinc-500 text-sm leading-relaxed">{description}</p>
  </motion.div>
);
