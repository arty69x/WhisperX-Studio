import React from 'react';
import { motion } from 'framer-motion';

interface LocationData {
  country: string;
  count: number;
  lat: number;
  lng: number;
}

interface LocationMapProps {
  locations: LocationData[];
}

export const LocationMap: React.FC<LocationMapProps> = ({ locations }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      className="relative w-full h-[400px] bg-black/40 backdrop-blur-xl border border-white/10 rounded-2xl overflow-hidden p-6"
    >
      <div className="absolute top-6 left-6 z-10">
        <h3 className="text-white font-medium text-lg tracking-tight">Geographic Resonance</h3>
        <p className="text-zinc-500 text-xs font-mono uppercase tracking-widest mt-1">Global Signal Propagation</p>
      </div>

      <div className="relative w-full h-full flex items-center justify-center">
        {/* Simple Abstract World Map Paths */}
        <svg viewBox="0 0 1000 500" className="w-full h-full opacity-20">
          <path 
            fill="currentColor" 
            className="text-zinc-800"
            d="M200,100 Q400,50 600,100 T800,100 T900,200 T800,400 T400,450 T100,300 Z" 
          />
          <path 
            fill="currentColor" 
            className="text-zinc-800"
            d="M100,50 L150,80 L120,120 Z M800,50 L850,80 L820,120 Z" 
          />
        </svg>

        {/* Resonance Points */}
        {locations.map((loc, i) => {
          // Abstract projection for visualization
          const x = 500 + (loc.lng * 2.5);
          const y = 250 - (loc.lat * 2.5);
          
          return (
            <motion.div
              key={loc.country}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: i * 0.2, type: 'spring' }}
              className="absolute group"
              style={{ left: `${(x / 1000) * 100}%`, top: `${(y / 500) * 100}%` }}
            >
              {/* Pulse effect */}
              <div className="absolute inset-0 w-8 h-8 -translate-x-1/2 -translate-y-1/2 rounded-full bg-emerald-500/20 animate-ping" />
              <div className="w-3 h-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-emerald-500 border-2 border-white shadow-[0_0_15px_rgba(16,185,129,0.5)] z-10" />
              
              {/* Tooltip on hover */}
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none whitespace-nowrap bg-black/90 border border-white/20 rounded-lg px-3 py-1.5 text-[10px] text-white backdrop-blur-md z-20">
                <span className="font-bold">{loc.country}</span>: <span className="text-emerald-400 font-mono">{loc.count}</span>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Legend */}
      <div className="absolute bottom-6 right-6 flex items-center gap-4">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-500" />
          <span className="text-[10px] text-zinc-400 font-mono tracking-tighter uppercase">High Interaction</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-violet-500" />
          <span className="text-[10px] text-zinc-400 font-mono tracking-tighter uppercase">Active Nodes</span>
        </div>
      </div>
    </motion.div>
  );
};
