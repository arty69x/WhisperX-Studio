import React, { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Plus, 
  Settings, 
  Play, 
  Save, 
  Download, 
  Trash2, 
  Cpu, 
  Layers, 
  Zap,
  Activity,
  Maximize2,
  Minimize2
} from 'lucide-react';
import { useNexus } from '@/lib/nexus-context';
import { cn } from '@/lib/utils';

// Types for the Visual Forge
interface NodeDef {
  type: string;
  label: string;
  description: string;
  icon: any;
  color: string;
}

const NODE_DEFS: Record<string, NodeDef> = {
  intelligence: { 
    type: 'intelligence', 
    label: 'Nexus Core', 
    description: 'Neural processing unit that synthesizes global sentiment streams into usable intelligence vectors.',
    icon: Brain,
    color: 'text-violet-400'
  },
  oscillator: { 
    type: 'oscillator', 
    label: 'Signal Oscillator', 
    description: 'Generates periodic fluctuations based on sentiment volatility indices.',
    icon: Activity,
    color: 'text-blue-400'
  },
  emitter: { 
    type: 'emitter', 
    label: 'Data Emitter', 
    description: 'Projects processed intelligence tokens into external visualization nodes.',
    icon: Zap,
    color: 'text-emerald-400'
  },
  modifier: { 
    type: 'modifier', 
    label: 'Pattern Modifier', 
    description: 'Alters signal characteristics through cryptographic entropy filters.',
    icon: Layers,
    color: 'text-amber-400'
  }
};

interface Node {
  id: string;
  type: keyof typeof NODE_DEFS;
  x: number;
  y: number;
  label: string;
  params: Record<string, any>;
  validation?: string | null;
}

interface Edge {
  id: string;
  from: string;
  to: string;
}

export const CanvasStudio: React.FC = () => {
  const { result } = useNexus();
  const [nodes, setNodes] = useState<Node[]>([]);
  const [edges, setEdges] = useState<Edge[]>([]);
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);
  const canvasRef = useRef<HTMLDivElement>(null);

  // Initialize with Intelligence Node if sentiment exists
  useEffect(() => {
    if (result && nodes.length === 0) {
      const newNode: Node = {
        id: 'nexus-core',
        type: 'intelligence',
        x: 100,
        y: 100,
        label: 'Nexus Intelligence Core',
        params: { score: result.score, impact: result.impactLevel }
      };
      setNodes([newNode]);
    }
  }, [result]);

  const addNode = (type: Node['type']) => {
    const id = `${type}-${Date.now()}`;
    const newNode: Node = {
      id,
      type,
      x: 300,
      y: 200,
      label: `New ${type.charAt(0).toUpperCase() + type.slice(1)}`,
      params: {}
    };
    setNodes([...nodes, newNode]);
  };

  const updateNodeLabel = (id: string, label: string) => {
    setNodes(nodes.map(n => n.id === id ? { ...n, label } : n));
  };

  return (
    <div className="flex flex-col h-screen bg-[#050505] text-white overflow-hidden font-sans">
      {/* Top Controls */}
      <header className="h-16 border-b border-white/5 flex items-center justify-between px-6 bg-black/40 backdrop-blur-md">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-violet-500" />
            <h2 className="text-sm font-bold tracking-widest uppercase">Visual Forge <span className="text-zinc-600">v1.2</span></h2>
          </div>
          <div className="h-4 w-[1px] bg-white/10" />
          <div className="flex gap-2">
            <button onClick={() => addNode('oscillator')} className="p-2 hover:bg-white/5 rounded-lg text-zinc-400 hover:text-white transition-colors">
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button 
            onClick={() => setIsSimulating(!isSimulating)}
            className={cn(
              "px-4 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-2",
              isSimulating ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30" : "bg-white/5 text-zinc-500 border border-transparent"
            )}
          >
            <Play className={cn("w-3 h-3", isSimulating && "fill-emerald-400")} />
            {isSimulating ? "Synthesizing" : "Simulate"}
          </button>
          <div className="flex bg-white/5 rounded-full p-1 border border-white/10">
            <button className="px-3 py-1 text-xs font-bold hover:text-white text-zinc-500 transition-colors">Draft</button>
            <button className="px-3 py-1 text-xs font-bold bg-white text-black rounded-full shadow-lg">Finalize</button>
          </div>
        </div>
      </header>

      <div className="flex-1 flex relative">
        {/* Workspace Canvas */}
        <div 
          ref={canvasRef}
          className="flex-1 relative bg-[radial-gradient(#1a1a1a_1px,transparent_1px)] [background-size:20px_20px] overflow-hidden"
        >
          <AnimatePresence>
            {nodes.map(node => (
              <VisualNode 
                key={node.id} 
                node={node} 
                isSelected={selectedNode === node.id}
                onClick={() => setSelectedNode(node.id)}
                onUpdateLabel={updateNodeLabel}
                isSimulating={isSimulating}
              />
            ))}
          </AnimatePresence>

          {/* Connection Lines (Simplified SVG) */}
          <svg className="absolute inset-0 pointer-events-none w-full h-full">
             {edges.map(edge => {
               const from = nodes.find(n => n.id === edge.from);
               const to = nodes.find(n => n.id === edge.to);
               if (!from || !to) return null;
               return (
                 <motion.path
                   key={edge.id}
                   d={`M ${from.x + 100} ${from.y + 50} L ${to.x} ${to.y + 50}`}
                   stroke="rgba(139, 92, 246, 0.2)"
                   strokeWidth="1"
                   fill="none"
                 />
               );
             })}
          </svg>
        </div>

        {/* Node Inspector */}
        <aside className="w-80 border-l border-white/5 bg-black/40 backdrop-blur-xl p-6 overflow-y-auto">
          <div className="mb-8">
            <h3 className="text-zinc-500 text-[10px] font-mono uppercase tracking-widest mb-4">Properties</h3>
            {selectedNode ? (
              <div className="space-y-6">
                <div>
                  <label className="text-[10px] text-zinc-600 block mb-2 uppercase">Type</label>
                  <div className="flex items-center gap-2">
                    {(() => {
                      const node = nodes.find(n => n.id === selectedNode);
                      const def = node ? NODE_DEFS[node.type] : null;
                      if (!def) return null;
                      return (
                        <>
                          <def.icon className={cn("w-4 h-4", def.color)} />
                          <span className="text-white font-medium">{def.label}</span>
                        </>
                      );
                    })()}
                  </div>
                </div>

                <div>
                  <label className="text-[10px] text-zinc-600 block mb-2 uppercase">Description</label>
                  <p className="text-zinc-400 text-xs leading-relaxed">
                    {nodes.find(n => n.id === selectedNode)?.type ? NODE_DEFS[nodes.find(n => n.id === selectedNode)!.type].description : ''}
                  </p>
                </div>

                {nodes.find(n => n.id === selectedNode)?.validation && (
                   <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-lg">
                      <div className="flex items-center gap-2 mb-1">
                        <Activity className="w-3 h-3 text-rose-500" />
                        <span className="text-[10px] font-bold text-rose-500 uppercase tracking-widest">Validation Error</span>
                      </div>
                      <p className="text-[10px] text-rose-400 font-mono leading-tight">
                        {nodes.find(n => n.id === selectedNode)?.validation}
                      </p>
                   </div>
                )}

                <div>
                  <label className="text-[10px] text-zinc-600 block mb-2 uppercase">Direct Identity</label>
                  <input 
                    value={nodes.find(n => n.id === selectedNode)?.label || ''}
                    onChange={(e) => {
                      const newLabel = e.target.value;
                      setNodes(nodes.map(n => n.id === selectedNode ? { ...n, label: newLabel } : n));
                    }}
                    className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-violet-500"
                  />
                </div>
                
                <div className="space-y-4">
                  <PropertyControl label="Gain" value={75} />
                  <PropertyControl label="Frequency" value={142} />
                  <PropertyControl label="Entropy" value={12} />
                </div>
              </div>
            ) : (
                <div className="text-center py-12">
                   <Activity className="w-8 h-8 text-zinc-800 mx-auto mb-4" />
                   <p className="text-zinc-600 text-xs italic">Select a node to inspect parameters</p>
                </div>
            )}
          </div>

          <div className="pt-8 border-t border-white/5">
            <h3 className="text-zinc-500 text-[10px] font-mono uppercase tracking-widest mb-4">Actions</h3>
            <div className="grid grid-cols-2 gap-3">
              <ActionButton icon={Save} label="Archive" />
              <ActionButton icon={Download} label="Export" />
              <ActionButton icon={Trash2} label="Purge" className="text-rose-500" />
            </div>
          </div>
        </aside>
      </div>

      {/* Floating Status Bar */}
      <footer className="h-10 border-t border-white/5 bg-black/60 backdrop-blur-md flex items-center justify-between px-6">
        <div className="flex gap-4 items-center">
           <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              <span className="text-[10px] text-zinc-500 font-mono tracking-tighter uppercase">Local Kernel Active</span>
           </div>
           <span className="text-[10px] text-zinc-700 font-mono">LAT_0.02ms</span>
        </div>
        <div className="flex gap-4">
           <Maximize2 className="w-3.5 h-3.5 text-zinc-600 cursor-pointer hover:text-white transition-colors" />
        </div>
      </footer>
    </div>
  );
};

const VisualNode: React.FC<{ 
  node: Node; 
  isSelected: boolean; 
  onClick: () => void;
  isSimulating: boolean;
  onUpdateLabel: (id: string, label: string) => void;
}> = ({ node, isSelected, onClick, isSimulating, onUpdateLabel }) => {
  const [isEditing, setIsEditing] = useState(false);
  const def = NODE_DEFS[node.type];

  return (
    <motion.div
      drag
      dragMomentum={false}
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ 
        opacity: 1, 
        scale: isSelected ? 1.05 : 1,
        y: isSimulating ? [0, -5, 0] : 0
      }}
      transition={{ 
        y: { 
          repeat: Infinity, 
          duration: 3, 
          ease: "easeInOut",
          delay: Math.random() * 2 
        } 
      }}
      onClick={onClick}
      onDoubleClick={() => setIsEditing(true)}
      className={cn(
        "absolute w-56 p-4 rounded-xl border transition-all cursor-move select-none backdrop-blur-md",
        isSelected ? "bg-white/10 border-violet-500 shadow-[0_0_20px_rgba(139,92,246,0.2)]" : "bg-black/60 border-white/10 hover:border-white/20",
        node.validation && "border-rose-500/50"
      )}
      style={{ left: node.x, top: node.y }}
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          {def && <def.icon className={cn("w-3.5 h-3.5", def.color)} />}
          <span className="text-[10px] font-mono text-zinc-400 group-hover:text-white uppercase tracking-widest">{node.type}</span>
        </div>
        {(isSimulating || node.validation) && (
          <div className={cn("w-1.5 h-1.5 rounded-full animate-pulse", node.validation ? "bg-rose-500" : "bg-emerald-500")} />
        )}
      </div>

      {isEditing ? (
        <input 
          autoFocus
          value={node.label}
          onChange={(e) => onUpdateLabel(node.id, e.target.value)}
          onBlur={() => setIsEditing(false)}
          onKeyDown={(e) => e.key === 'Enter' && setIsEditing(false)}
          className="w-full bg-white/10 border border-white/20 rounded px-2 py-1 text-sm text-white mb-1"
        />
      ) : (
        <h4 className="text-white text-sm font-medium mb-1 truncate">{node.label}</h4>
      )}
      
      <p className="text-[10px] text-zinc-600 truncate">{node.id}</p>
      
      {/* Port Logic (Visual only for now) */}
      <div className="mt-4 flex justify-between">
         <div className="w-2 h-2 rounded-full bg-zinc-800 border border-white/10 -ml-5" />
         <div className="w-2 h-2 rounded-full bg-emerald-500 border border-white/10 -mr-5" />
      </div>
    </motion.div>
  );
};

const PropertyControl: React.FC<{ label: string; value: number }> = ({ label, value }) => (
  <div>
    <div className="flex justify-between items-center mb-1.5">
      <label className="text-[10px] text-zinc-500 uppercase font-mono tracking-tighter">{label}</label>
      <span className="text-[10px] text-white font-mono">{value}</span>
    </div>
    <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
      <div className="h-full bg-violet-600" style={{ width: `${(value/200)*100}%` }} />
    </div>
  </div>
);

const ActionButton: React.FC<{ icon: any; label: string; className?: string }> = ({ icon: Icon, label, className }) => (
  <button className={cn("flex items-center justify-center gap-2 py-2 px-4 rounded-lg bg-white/5 border border-white/5 hover:border-white/10 hover:bg-white/10 transition-all text-[10px] font-bold text-zinc-400 hover:text-white", className)}>
    <Icon className="w-3.5 h-3.5" />
    {label}
  </button>
);
