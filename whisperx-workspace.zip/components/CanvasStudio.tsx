'use client';

import React, { useState, useRef, useEffect, useReducer, useCallback, useMemo } from "react";
import { motion } from "motion/react";
import { Lightbulb, Terminal, ArrowRight, Settings, Plus, Play, Pause, Grid, Layers, Trash2, Undo2, Redo2, Maximize, ZoomIn, Search, BrainCircuit, Activity, Cpu } from 'lucide-react';
import { useNexus } from "@/lib/nexus-context";

// ═══════════════════════════════════════════════════════════════════
//  DESIGN TOKENS
// ═══════════════════════════════════════════════════════════════════
const T = {
  bg: "#050505",
  bg1: "#0A0A0A",
  bg2: "#0F0F0F",
  bg3: "#161616",
  bg4: "#1C1C1C",
  line: "rgba(255,255,255,0.05)",
  line2: "rgba(255,255,255,0.1)",
  line3: "rgba(255,255,255,0.2)",
  text: "#FAFAFA",
  textSub: "#A1A1AA",
  textDim: "#52525B",
  white: "#FFFFFF",
  red: "#F43F5E",
  orange: "#F59E0B",
  yellow: "#FBBF24",
  green: "#10B981",
  blue: "#3B82F6",
  cyan: "#06B6D4",
  purple: "#8B5CF6",
  pink: "#EC4899",
  emerald: "#10B981",
  violet: "#8B5CF6",
  grad: "linear-gradient(135deg, #8B5CF6, #10B981)",
  sans: "var(--font-sans)",
  mono: "var(--font-mono)",
  disp: "var(--font-display)",
};

// ═══════════════════════════════════════════════════════════════════
//  NODE DEFINITIONS
// ═══════════════════════════════════════════════════════════════════
const PORT = { IN: "in", OUT: "out", FLOW_IN: "flow_in", FLOW_OUT: "flow_out" };
const TYPES = {
  ANY: "any",
  NUMBER: "number",
  STRING: "string",
  BOOL: "bool",
  COLOR: "color",
  VEC2: "vec2",
  VEC3: "vec3",
  IMAGE: "image",
  ARRAY: "array",
  OBJECT: "object",
  EVENT: "event",
  FLOW: "flow"
};

const PORT_COLORS: Record<string, string> = {
  [TYPES.NUMBER]: T.cyan,
  [TYPES.STRING]: T.orange,
  [TYPES.BOOL]: T.yellow,
  [TYPES.COLOR]: T.pink,
  [TYPES.VEC2]: T.green,
  [TYPES.VEC3]: T.blue,
  [TYPES.IMAGE]: T.purple,
  [TYPES.ARRAY]: T.red,
  [TYPES.OBJECT]: T.textSub,
  [TYPES.EVENT]: T.red,
  [TYPES.FLOW]: T.textDim,
  [TYPES.ANY]: T.text,
};

const mkPort = (id: string, label: string, type: string, dir: string, defaultVal: any = null) => ({ id, label, type, dir, defaultVal });

const NODE_DEFS: any = {
  // ── MATH ──
  add: { 
    cat: "Math", label: "Add", icon: "＋", color: T.cyan,
    description: "Adds two numerical values together.",
    ports: [mkPort("a", "A", TYPES.NUMBER, PORT.IN, 0), mkPort("b", "B", TYPES.NUMBER, PORT.IN, 0), mkPort("out", "Out", TYPES.NUMBER, PORT.OUT)],
    compute: ({ a = 0, b = 0 }: any) => ({ out: a + b }) 
  },
  subtract: { 
    cat: "Math", label: "Subtract", icon: "－", color: T.cyan,
    description: "Subtracts the second numerical value from the first.",
    ports: [mkPort("a", "A", TYPES.NUMBER, PORT.IN, 0), mkPort("b", "B", TYPES.NUMBER, PORT.IN, 0), mkPort("out", "Out", TYPES.NUMBER, PORT.OUT)],
    compute: ({ a = 0, b = 0 }: any) => ({ out: a - b }) 
  },
  multiply: { 
    cat: "Math", label: "Multiply", icon: "×", color: T.cyan,
    description: "Multiplies two numerical values together.",
    ports: [mkPort("a", "A", TYPES.NUMBER, PORT.IN, 1), mkPort("b", "B", TYPES.NUMBER, PORT.IN, 1), mkPort("out", "Out", TYPES.NUMBER, PORT.OUT)],
    compute: ({ a = 1, b = 1 }: any) => ({ out: a * b }) 
  },
  divide: { 
    cat: "Math", label: "Divide", icon: "÷", color: T.cyan,
    description: "Divides the first numerical value by the second.",
    ports: [mkPort("a", "A", TYPES.NUMBER, PORT.IN, 1), mkPort("b", "B", TYPES.NUMBER, PORT.IN, 1), mkPort("out", "Out", TYPES.NUMBER, PORT.OUT)],
    compute: ({ a = 1, b = 1 }: any) => ({ out: b !== 0 ? a / b : 0 }) 
  },
  power: { 
    cat: "Math", label: "Power", icon: "xⁿ", color: T.cyan,
    description: "Raises a base number to a specific exponent.",
    ports: [mkPort("base", "Base", TYPES.NUMBER, PORT.IN, 2), mkPort("exp", "Exp", TYPES.NUMBER, PORT.IN, 2), mkPort("out", "Out", TYPES.NUMBER, PORT.OUT)],
    compute: ({ base = 2, exp = 2 }: any) => ({ out: Math.pow(base, exp) }) 
  },
  clamp: { 
    cat: "Math", label: "Clamp", icon: "⟂", color: T.cyan,
    description: "Restricts a value between a minimum and maximum range.",
    ports: [mkPort("v", "Value", TYPES.NUMBER, PORT.IN, 0.5), mkPort("min", "Min", TYPES.NUMBER, PORT.IN, 0), mkPort("max", "Max", TYPES.NUMBER, PORT.IN, 1), mkPort("out", "Out", TYPES.NUMBER, PORT.OUT)],
    compute: ({ v = 0.5, min = 0, max = 1 }: any) => ({ out: Math.min(max, Math.max(min, v)) }) 
  },
  lerp: { 
    cat: "Math", label: "Lerp", icon: "↔", color: T.cyan,
    description: "Linearly interpolates between two values by a factor T.",
    ports: [mkPort("a", "A", TYPES.NUMBER, PORT.IN, 0), mkPort("b", "B", TYPES.NUMBER, PORT.IN, 1), mkPort("t", "T", TYPES.NUMBER, PORT.IN, 0.5), mkPort("out", "Out", TYPES.NUMBER, PORT.OUT)],
    compute: ({ a = 0, b = 1, t = 0.5 }: any) => ({ out: a + (b - a) * t }) 
  },
  sin: { 
    cat: "Math", label: "Sin", icon: "∿", color: T.cyan,
    description: "Calculates the sine of an input value.",
    ports: [mkPort("x", "X", TYPES.NUMBER, PORT.IN, 0), mkPort("out", "Out", TYPES.NUMBER, PORT.OUT)],
    compute: ({ x = 0 }: any) => ({ out: Math.sin(x) }) 
  },
  cos: { 
    cat: "Math", label: "Cos", icon: "∿", color: T.cyan,
    description: "Calculates the cosine of an input value.",
    ports: [mkPort("x", "X", TYPES.NUMBER, PORT.IN, 0), mkPort("out", "Out", TYPES.NUMBER, PORT.OUT)],
    compute: ({ x = 0 }: any) => ({ out: Math.cos(x) }) 
  },
  abs: { 
    cat: "Math", label: "Abs", icon: "|x|", color: T.cyan,
    description: "Returns the absolute value of a number.",
    ports: [mkPort("x", "X", TYPES.NUMBER, PORT.IN, 0), mkPort("out", "Out", TYPES.NUMBER, PORT.OUT)],
    compute: ({ x = 0 }: any) => ({ out: Math.abs(x) }) 
  },
  // ── LOGIC ──
  compare: { 
    cat: "Logic", label: "Compare", icon: "⊜", color: T.yellow,
    description: "Compares two numbers and returns boolean results.",
    ports: [mkPort("a", "A", TYPES.NUMBER, PORT.IN, 0), mkPort("b", "B", TYPES.NUMBER, PORT.IN, 0), mkPort("gt", ">", TYPES.BOOL, PORT.OUT), mkPort("eq", "=", TYPES.BOOL, PORT.OUT), mkPort("lt", "<", TYPES.BOOL, PORT.OUT)],
    compute: ({ a = 0, b = 0 }: any) => ({ gt: a > b, eq: a === b, lt: a < b }) 
  },
  gate: { 
    cat: "Logic", label: "Gate", icon: "⊓", color: T.yellow,
    description: "Passes data through different outputs based on a condition.",
    ports: [mkPort("in", "In", TYPES.ANY, PORT.IN), mkPort("cond", "Cond", TYPES.BOOL, PORT.IN, true), mkPort("true", "True", TYPES.ANY, PORT.OUT), mkPort("false", "False", TYPES.ANY, PORT.OUT)],
    compute: ({ in: v, cond }: any) => ({ true: cond ? v : null, false: !cond ? v : null }) 
  },
  not: { 
    cat: "Logic", label: "NOT", icon: "¬", color: T.yellow,
    description: "Inverts a boolean value.",
    ports: [mkPort("in", "In", TYPES.BOOL, PORT.IN, false), mkPort("out", "Out", TYPES.BOOL, PORT.OUT)],
    compute: ({ in: v }: any) => ({ out: !v }) 
  },
  and: { 
    cat: "Logic", label: "AND", icon: "∧", color: T.yellow,
    description: "Checks if both boolean inputs are true.",
    ports: [mkPort("a", "A", TYPES.BOOL, PORT.IN, true), mkPort("b", "B", TYPES.BOOL, PORT.IN, true), mkPort("out", "Out", TYPES.BOOL, PORT.OUT)],
    compute: ({ a, b }: any) => ({ out: !!a && !!b }) 
  },
  or: { 
    cat: "Logic", label: "OR", icon: "∨", color: T.yellow,
    description: "Checks if at least one boolean input is true.",
    ports: [mkPort("a", "A", TYPES.BOOL, PORT.IN, false), mkPort("b", "B", TYPES.BOOL, PORT.IN, false), mkPort("out", "Out", TYPES.BOOL, PORT.OUT)],
    compute: ({ a, b }: any) => ({ out: !!a || !!b }) 
  },
  // ── VECTOR ──
  vec2: { 
    cat: "Vector", label: "Vec2", icon: "⃗", color: T.green,
    description: "Combines two numbers into a 2D vector.",
    ports: [mkPort("x", "X", TYPES.NUMBER, PORT.IN, 0), mkPort("y", "Y", TYPES.NUMBER, PORT.IN, 0), mkPort("out", "XY", TYPES.VEC2, PORT.OUT)],
    compute: ({ x = 0, y = 0 }: any) => ({ out: { x, y } }) 
  },
  vec3: { 
    cat: "Vector", label: "Vec3", icon: "⃗", color: T.green,
    description: "Combines three numbers into a 3D vector.",
    ports: [mkPort("x", "X", TYPES.NUMBER, PORT.IN, 0), mkPort("y", "Y", TYPES.NUMBER, PORT.IN, 0), mkPort("z", "Z", TYPES.NUMBER, PORT.IN, 0), mkPort("out", "XYZ", TYPES.VEC3, PORT.OUT)],
    compute: ({ x = 0, y = 0, z = 0 }: any) => ({ out: { x, y, z } }) 
  },
  splitVec2: { 
    cat: "Vector", label: "Split XY", icon: "⊕", color: T.green,
    description: "Separates a 2D vector into its individual components.",
    ports: [mkPort("in", "XY", TYPES.VEC2, PORT.IN), mkPort("x", "X", TYPES.NUMBER, PORT.OUT), mkPort("y", "Y", TYPES.NUMBER, PORT.OUT)],
    compute: ({ in: v }: any) => ({ x: v?.x || 0, y: v?.y || 0 }) 
  },
  distance: { 
    cat: "Vector", label: "Distance", icon: "↦", color: T.green,
    description: "Calculates the distance between two 2D vectors.",
    ports: [mkPort("a", "A", TYPES.VEC2, PORT.IN), mkPort("b", "B", TYPES.VEC2, PORT.IN), mkPort("out", "Dist", TYPES.NUMBER, PORT.OUT)],
    compute: ({ a, b }: any) => ({ out: Math.sqrt(Math.pow((b?.x || 0) - (a?.x || 0), 2) + Math.pow((b?.y || 0) - (a?.y || 0), 2)) }) 
  },
  normalize: { 
    cat: "Vector", label: "Normalize", icon: "‖v‖", color: T.green,
    description: "Scales a vector to a length of 1 while maintaining direction.",
    ports: [mkPort("in", "Vec2", TYPES.VEC2, PORT.IN), mkPort("out", "Norm", TYPES.VEC2, PORT.OUT)],
    compute: ({ in: v }: any) => { const l = Math.sqrt((v?.x || 0) ** 2 + (v?.y || 0) ** 2) || 1; return { out: { x: (v?.x || 0) / l, y: (v?.y || 0) / l } }; } 
  },
  // ── COLOR ──
  rgb: { 
    cat: "Color", label: "RGB", icon: "◉", color: T.pink,
    description: "Creates a color from Red, Green, and Blue values.",
    ports: [mkPort("r", "R", TYPES.NUMBER, PORT.IN, 1), mkPort("g", "G", TYPES.NUMBER, PORT.IN, 0), mkPort("b", "B", TYPES.NUMBER, PORT.IN, 0), mkPort("out", "Color", TYPES.COLOR, PORT.OUT)],
    compute: ({ r = 1, g = 0, b = 0 }: any) => ({ out: `rgb(${Math.round(r * 255)},${Math.round(g * 255)},${Math.round(b * 255)})` }) 
  },
  hsl: { 
    cat: "Color", label: "HSL", icon: "◎", color: T.pink,
    description: "Creates a color from Hue, Saturation, and Lightness values.",
    ports: [mkPort("h", "H", TYPES.NUMBER, PORT.IN, 0), mkPort("s", "S", TYPES.NUMBER, PORT.IN, 1), mkPort("l", "L", TYPES.NUMBER, PORT.IN, 0.5), mkPort("out", "Color", TYPES.COLOR, PORT.OUT)],
    compute: ({ h = 0, s = 1, l = 0.5 }: any) => ({ out: `hsl(${Math.round(h * 360)},${Math.round(s * 100)}%,${Math.round(l * 100)}%)` }) 
  },
  mixColor: { 
    cat: "Color", label: "Mix Color", icon: "⊗", color: T.pink,
    description: "Switches between two colors based on a factor T.",
    ports: [mkPort("a", "A", TYPES.COLOR, PORT.IN, "#F43F5E"), mkPort("b", "B", TYPES.COLOR, PORT.IN, "#3B82F6"), mkPort("t", "T", TYPES.NUMBER, PORT.IN, 0.5), mkPort("out", "Mix", TYPES.COLOR, PORT.OUT)],
    compute: ({ a = "#F43F5E", b = "#3B82F6", t = 0.5 }: any) => ({ out: t < 0.5 ? a : b }) 
  },
  // ── INPUT ──
  number: { 
    cat: "Input", label: "Number", icon: "#", color: T.orange,
    description: "Allows manual input of a numerical value.",
    ports: [mkPort("out", "Value", TYPES.NUMBER, PORT.OUT)],
    value: 0,
    compute: (_: any, { value = 0 }: any) => ({ out: parseFloat(value) || 0 }) 
  },
  string: { 
    cat: "Input", label: "String", icon: "Aa", color: T.orange,
    description: "Allows manual input of a text string.",
    ports: [mkPort("out", "Value", TYPES.STRING, PORT.OUT)],
    value: "Hello",
    compute: (_: any, { value = "" }: any) => ({ out: String(value) }) 
  },
  bool: { 
    cat: "Input", label: "Bool", icon: "⊡", color: T.orange,
    description: "Allows manual input of a boolean toggle.",
    ports: [mkPort("out", "Value", TYPES.BOOL, PORT.OUT)],
    value: true,
    compute: (_: any, { value }: any) => ({ out: !!value }) 
  },
  slider: { 
    cat: "Input", label: "Slider", icon: "⊟", color: T.orange,
    description: "Provides a slider interface for numerical input.",
    ports: [mkPort("out", "Value", TYPES.NUMBER, PORT.OUT)],
    value: 0.5, min: 0, max: 1,
    compute: (_: any, { value = 0.5 }: any) => ({ out: parseFloat(value) || 0 }) 
  },
  colorPicker: { 
    cat: "Input", label: "Color", icon: "🎨", color: T.pink,
    description: "Provides a color picker for color input.",
    ports: [mkPort("out", "Color", TYPES.COLOR, PORT.OUT)],
    value: "#F43F5E",
    compute: (_: any, { value = "#F43F5E" }: any) => ({ out: value }) 
  },
  time: { 
    cat: "Input", label: "Time", icon: "⏱", color: T.orange,
    description: "Outputs continuously updating time and trig values.",
    ports: [mkPort("out", "T", TYPES.NUMBER, PORT.OUT), mkPort("sin", "Sin", TYPES.NUMBER, PORT.OUT), mkPort("cos", "Cos", TYPES.NUMBER, PORT.OUT)],
    compute: () => { const t = Date.now() / 1000; return { out: t, sin: Math.sin(t), cos: Math.cos(t) }; } 
  },
  // ── OUTPUT / DISPLAY ──
  display: { 
    cat: "Output", label: "Display", icon: "▦", color: T.blue,
    description: "Shows the incoming value in the sidebar.",
    ports: [mkPort("in", "Value", TYPES.ANY, PORT.IN)],
    compute: () => ({}) 
  },
  // ── SHAPE / SVG ──
  circle: { 
    cat: "Shape", label: "Circle", icon: "○", color: T.purple,
    description: "Generates an SVG circle path string.",
    ports: [mkPort("cx", "CX", TYPES.NUMBER, PORT.IN, 100), mkPort("cy", "CY", TYPES.NUMBER, PORT.IN, 100), mkPort("r", "R", TYPES.NUMBER, PORT.IN, 40), mkPort("fill", "Fill", TYPES.COLOR, PORT.IN, "#F43F5E"), mkPort("stroke", "Stroke", TYPES.COLOR, PORT.IN, "none"), mkPort("sw", "StrokeW", TYPES.NUMBER, PORT.IN, 0), mkPort("opacity", "Opacity", TYPES.NUMBER, PORT.IN, 1), mkPort("out", "SVG", TYPES.STRING, PORT.OUT)],
    compute: ({ cx = 100, cy = 100, r = 40, fill = "#F43F5E", stroke = "none", sw = 0, opacity = 1 }: any) => ({ out: `<circle cx="${cx}" cy="${cy}" r="${Math.max(0, r)}" fill="${fill}" stroke="${stroke}" stroke-width="${sw}" opacity="${opacity}"/>` }) 
  },
  rect: { 
    cat: "Shape", label: "Rect", icon: "▭", color: T.purple,
    description: "Generates an SVG rectangle path string.",
    ports: [mkPort("x", "X", TYPES.NUMBER, PORT.IN, 50), mkPort("y", "Y", TYPES.NUMBER, PORT.IN, 50), mkPort("w", "W", TYPES.NUMBER, PORT.IN, 120), mkPort("h", "H", TYPES.NUMBER, PORT.IN, 80), mkPort("rx", "RX", TYPES.NUMBER, PORT.IN, 8), mkPort("fill", "Fill", TYPES.COLOR, PORT.IN, "#3B82F6"), mkPort("opacity", "Opacity", TYPES.NUMBER, PORT.IN, 1), mkPort("out", "SVG", TYPES.STRING, PORT.OUT)],
    compute: ({ x = 50, y = 50, w = 120, h = 80, rx = 8, fill = "#3B82F6", opacity = 1 }: any) => ({ out: `<rect x="${x}" y="${y}" width="${Math.max(0, w)}" height="${Math.max(0, h)}" rx="${rx}" fill="${fill}" opacity="${opacity}"/>` }) 
  },
  line: { 
    cat: "Shape", label: "Line", icon: "╱", color: T.purple,
    description: "Generates an SVG line path string.",
    ports: [mkPort("x1", "X1", TYPES.NUMBER, PORT.IN, 0), mkPort("y1", "Y1", TYPES.NUMBER, PORT.IN, 0), mkPort("x2", "X2", TYPES.NUMBER, PORT.IN, 100), mkPort("y2", "Y2", TYPES.NUMBER, PORT.IN, 100), mkPort("stroke", "Color", TYPES.COLOR, PORT.IN, "#F59E0B"), mkPort("sw", "Width", TYPES.NUMBER, PORT.IN, 2), mkPort("out", "SVG", TYPES.STRING, PORT.OUT)],
    compute: ({ x1 = 0, y1 = 0, x2 = 100, y2 = 100, stroke = "#F59E0B", sw = 2 }: any) => ({ out: `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${stroke}" stroke-width="${sw}" stroke-linecap="round"/>` }) 
  },
  text: { 
    cat: "Shape", label: "Text", icon: "T", color: T.purple,
    description: "Generates an SVG text element string.",
    ports: [mkPort("x", "X", TYPES.NUMBER, PORT.IN, 100), mkPort("y", "Y", TYPES.NUMBER, PORT.IN, 100), mkPort("text", "Text", TYPES.STRING, PORT.IN, "Hello"), mkPort("size", "Size", TYPES.NUMBER, PORT.IN, 20), mkPort("fill", "Fill", TYPES.COLOR, PORT.IN, "#FAFAFA"), mkPort("out", "SVG", TYPES.STRING, PORT.OUT)],
    compute: ({ x = 100, y = 100, text = "Hello", size = 20, fill = "#FAFAFA" }: any) => ({ out: `<text x="${x}" y="${y}" font-size="${size}" fill="${fill}" font-family="var(--font-sans)" dominant-baseline="middle" text-anchor="middle">${text}</text>` }) 
  },
  // ── TRANSFORM ──
  translate: { 
    cat: "Transform", label: "Translate", icon: "⇢", color: T.green,
    description: "Moves an SVG object by a specified offset.",
    ports: [mkPort("in", "SVG", TYPES.STRING, PORT.IN, ""), mkPort("x", "X", TYPES.NUMBER, PORT.IN, 0), mkPort("y", "Y", TYPES.NUMBER, PORT.IN, 0), mkPort("out", "SVG", TYPES.STRING, PORT.OUT)],
    compute: ({ in: svg = "", x = 0, y = 0 }: any) => ({ out: `<g transform="translate(${x},${y})">${svg}</g>` }) 
  },
  rotate: { 
    cat: "Transform", label: "Rotate", icon: "↻", color: T.green,
    description: "Rotates an SVG object around a center point.",
    ports: [mkPort("in", "SVG", TYPES.STRING, PORT.IN, ""), mkPort("angle", "Angle", TYPES.NUMBER, PORT.IN, 0), mkPort("cx", "CX", TYPES.NUMBER, PORT.IN, 0), mkPort("cy", "CY", TYPES.NUMBER, PORT.IN, 0), mkPort("out", "SVG", TYPES.STRING, PORT.OUT)],
    compute: ({ in: svg = "", angle = 0, cx = 0, cy = 0 }: any) => ({ out: `<g transform="rotate(${angle},${cx},${cy})">${svg}</g>` }) 
  },
  group: { 
    cat: "Transform", label: "Group", icon: "⬜", color: T.green,
    description: "Combines multiple SVG strings into a single group.",
    ports: [mkPort("a", "A", TYPES.STRING, PORT.IN, ""), mkPort("b", "B", TYPES.STRING, PORT.IN, ""), mkPort("c", "C", TYPES.STRING, PORT.IN, ""), mkPort("out", "SVG", TYPES.STRING, PORT.OUT)],
    compute: ({ a = "", b = "", c = "" }: any) => ({ out: `<g>${a}${b}${c}</g>` }) 
  },
  // ── ANIMATION ──
  oscillate: { 
    cat: "Animation", label: "Oscillate", icon: "∿", color: T.red,
    description: "Creates a value that moves back and forth between two numbers.",
    ports: [mkPort("min", "Min", TYPES.NUMBER, PORT.IN, 0), mkPort("max", "Max", TYPES.NUMBER, PORT.IN, 1), mkPort("speed", "Speed", TYPES.NUMBER, PORT.IN, 1), mkPort("out", "Out", TYPES.NUMBER, PORT.OUT)],
    compute: ({ min = 0, max = 1, speed = 1 }: any) => ({ out: min + (max - min) * (Math.sin(Date.now() / 1000 * speed * Math.PI * 2) * 0.5 + 0.5) }) 
  },
  noise: { 
    cat: "Animation", label: "Noise", icon: "≋", color: T.red,
    description: "Generates a pseudo-random value based on input and speed.",
    ports: [mkPort("x", "X", TYPES.NUMBER, PORT.IN, 0), mkPort("speed", "Speed", TYPES.NUMBER, PORT.IN, 0.5), mkPort("out", "Out", TYPES.NUMBER, PORT.OUT)],
    compute: ({ x = 0, speed = 0.5 }: any) => ({ out: (Math.sin(x * 127.1 + Date.now() / 1000 * speed) * 43758.5453) % 1 }) 
  },
  // ── ARRAY ──
  repeat: { 
    cat: "Array", label: "Repeat", icon: "⊞", color: T.red,
    description: "Repeats an SVG object a specified number of times with offsets.",
    ports: [mkPort("in", "SVG", TYPES.STRING, PORT.IN, ""), mkPort("n", "Count", TYPES.NUMBER, PORT.IN, 4), mkPort("dx", "dX", TYPES.NUMBER, PORT.IN, 60), mkPort("dy", "dY", TYPES.NUMBER, PORT.IN, 0), mkPort("out", "SVG", TYPES.STRING, PORT.OUT)],
    compute: ({ in: svg = "", n = 4, dx = 60, dy = 0 }: any) => ({ out: Array.from({ length: Math.min(50, Math.round(n)) }, (_, i) => `<g transform="translate(${i * dx},${i * dy})">${svg}</g>`).join("") }) 
  },
  // ── UTILITY ──
  map: { 
    cat: "Utility", label: "Remap", icon: "⇉", color: T.textSub,
    description: "Scales a value from one range to another.",
    ports: [mkPort("v", "In", TYPES.NUMBER, PORT.IN, 0), mkPort("il", "In Min", TYPES.NUMBER, PORT.IN, 0), mkPort("ih", "In Max", TYPES.NUMBER, PORT.IN, 1), mkPort("ol", "Out Min", TYPES.NUMBER, PORT.IN, 0), mkPort("oh", "Out Max", TYPES.NUMBER, PORT.IN, 100), mkPort("out", "Out", TYPES.NUMBER, PORT.OUT)],
    compute: ({ v = 0, il = 0, ih = 1, ol = 0, oh = 100 }: any) => ({ out: ol + (oh - ol) * ((v - il) / Math.max(0.0001, ih - il)) }) 
  },
  comment: { 
    cat: "Utility", label: "Comment", icon: "✎", color: T.textDim,
    description: "A simple sticky note for adding documentation to your graph.",
    ports: [], value: "Notes here…", compute: () => ({}) 
  },
  // ── INTELLIGENCE ──
  sentimentScore: {
    cat: "Intelligence", label: "Sentiment Result", icon: "🧠", color: T.violet,
    description: "Outputs the global average sentiment score from the last analysis (-1 to 1).",
    ports: [mkPort("out", "Score", TYPES.NUMBER, PORT.OUT)],
    compute: (_: any, __: any, env: any) => ({ out: env?.sentiment?.summary?.overallSentiment || 0 })
  },
  topInsight: {
    cat: "Intelligence", label: "Top Insight", icon: "✦", color: T.emerald,
    description: "Outputs the primary actionable insight identified by the AI.",
    ports: [mkPort("out", "Insight", TYPES.STRING, PORT.OUT)],
    compute: (_: any, __: any, env: any) => ({ out: env?.sentiment?.summary?.topActionables?.[0]?.title || "Awaiting Analysis..." })
  },
  insightImpact: {
    cat: "Intelligence", label: "Impact Level", icon: "⚡", color: T.orange,
    description: "Outputs the impact level of the top actionable insight.",
    ports: [mkPort("out", "Impact", TYPES.STRING, PORT.OUT)],
    compute: (_: any, __: any, env: any) => ({ out: env?.sentiment?.summary?.topActionables?.[0]?.impact || "N/A" })
  },
};

// ═══════════════════════════════════════════════════════════════════
//  STORE LOGIC
// ═══════════════════════════════════════════════════════════════════
const newNode = (type: string, x: number, y: number) => {
  const def = NODE_DEFS[type]; if (!def) return null;
  return {
    id: `n_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    type, x, y,
    w: type === "comment" ? 200 : 176,
    customLabel: def.label,
    selected: false,
    collapsed: false,
    value: def.value !== undefined ? def.value : undefined,
    min: def.min, max: def.max,
    portValues: {},
  };
};

const INITIAL_STATE = {
  nodes: [
    { ...newNode("time", 80, 80), id: "n_time" },
    { ...newNode("oscillate", 320, 60), id: "n_osc" },
    { ...newNode("circle", 580, 40), id: "n_cir" },
    { ...newNode("colorPicker", 320, 220), id: "n_col" },
    { ...newNode("repeat", 820, 40), id: "n_rep" },
  ],
  edges: [
    { id: "e1", from: "n_time", fromPort: "sin", to: "n_osc", toPort: "speed", label: "" },
    { id: "e2", from: "n_osc", fromPort: "out", to: "n_cir", toPort: "r", label: "" },
    { id: "e3", from: "n_col", fromPort: "out", to: "n_cir", toPort: "fill", label: "" },
    { id: "e4", from: "n_cir", fromPort: "out", to: "n_rep", toPort: "in", label: "" },
  ],
  history: [] as any[], future: [] as any[],
  pan: { x: 0, y: 0 }, zoom: 1,
  selNodes: [] as string[], selEdge: null as string | null,
  connecting: null as any,
  sidebar: "nodes",
  paused: false,
  grid: true,
  editingNode: null as string | null,
};

function reducer(s: typeof INITIAL_STATE, a: any) {
  const commit = (next: Partial<typeof INITIAL_STATE>) => {
    const h = [...s.history, { nodes: s.nodes, edges: s.edges }].slice(-60);
    return { ...s, ...next, history: h, future: [] };
  };
  switch (a.type) {
    case "NODE_ADD": return commit({ nodes: [...s.nodes, a.node] });
    case "NODE_UPD": return { ...s, nodes: s.nodes.map(n => n.id === a.id ? { ...n, ...a.p } : n) };
    case "NODE_EDIT_START": return { ...s, editingNode: a.id };
    case "NODE_EDIT_END": return { ...s, editingNode: null };
    case "NODE_MOVE": return { ...s, nodes: s.nodes.map(n => s.selNodes.includes(n.id) ? { ...n, x: n.x + a.dx, y: n.y + a.dy } : n) };
    case "NODE_DEL": return commit({ nodes: s.nodes.filter(n => !s.selNodes.includes(n.id)), edges: s.edges.filter(e => !s.selNodes.includes(e.from) && !s.selNodes.includes(e.to)), selNodes: [] });
    case "EDGE_ADD": return commit({ edges: [...s.edges, { ...a.edge, label: "" }], connecting: null });
    case "EDGE_UPD": return { ...s, edges: s.edges.map(e => e.id === a.id ? { ...e, ...a.p } : e) };
    case "EDGE_DEL": return commit({ edges: s.edges.filter(e => e.id !== a.id), selEdge: null });
    case "SEL": return { ...s, selNodes: a.ids, selEdge: a.edge || null };
    case "CONNECT": return { ...s, connecting: a.data };
    case "VIEW": return { ...s, pan: a.pan, zoom: a.zoom };
    case "SIDEBAR": return { ...s, sidebar: a.v };
    case "PAUSE": return { ...s, paused: !s.paused };
    case "GRID": return { ...s, grid: !s.grid };
    case "UNDO": {
      if (!s.history.length) return s;
      const prev = s.history[s.history.length - 1];
      return { ...s, ...prev, history: s.history.slice(0, -1), future: [{ nodes: s.nodes, edges: s.edges }, ...s.future] };
    }
    case "REDO": {
      if (!s.future.length) return s;
      const next = s.future[0];
      return { ...s, ...next, future: s.future.slice(1), history: [...s.history, { nodes: s.nodes, edges: s.edges }] };
    }
    case "CLEAR": return commit({ nodes: [], edges: [], selNodes: [], selEdge: null });
    default: return s;
  }
}

// ═══════════════════════════════════════════════════════════════════
//  VALIDATION
// ═══════════════════════════════════════════════════════════════════
function validateNode(node: any, edges: any[]) {
  const def = NODE_DEFS[node.type];
  if (!def) return { valid: false, errors: ["Missing definition"] };
  const errors: string[] = [];
  // For now, let's treat generic inputs that have no default value as required
  def.ports.filter((p: any) => p.dir === PORT.IN).forEach((p: any) => {
    const isConn = edges.some(e => e.to === node.id && e.toPort === p.id);
    const hasDefault = p.defaultVal !== null && p.defaultVal !== undefined;
    const hasManual = node.portValues?.[p.id] !== undefined;
    if (!isConn && !hasDefault && !hasManual) {
      errors.push(`Input "${p.label}" is missing connection or value.`);
    }
  });
  return { valid: errors.length === 0, errors };
}

// ═══════════════════════════════════════════════════════════════════
//  COMPUTE
// ═══════════════════════════════════════════════════════════════════
function computeGraph(nodes: any[], edges: any[], env: any = {}) {
  const vals: Record<string, any> = {};
  const visited = new Set();
  const order: string[] = [];
  const visit = (id: string) => {
    if (visited.has(id)) return; visited.add(id);
    edges.filter(e => e.to === id).forEach(e => visit(e.from));
    order.push(id);
  };
  nodes.forEach(n => visit(n.id));
  order.forEach(id => {
    const node = nodes.find(n => n.id === id); if (!node) return;
    const def = NODE_DEFS[node.type]; if (!def) return;
    const inVals: Record<string, any> = {};
    def.ports.filter((p: any) => p.dir === PORT.IN).forEach((p: any) => {
      const edge = edges.find(e => e.to === node.id && e.toPort === p.id);
      if (edge) { const src = vals[edge.from]; inVals[p.id] = src?.[edge.fromPort] ?? p.defaultVal; }
      else inVals[p.id] = node.portValues?.[p.id] ?? p.defaultVal;
    });
    try { vals[id] = def.compute(inVals, node, env); } catch { vals[id] = {}; }
  });
  return vals;
}

// ═══════════════════════════════════════════════════════════════════
//  COMPONENTS
// ═══════════════════════════════════════════════════════════════════
const PORT_H = 22;
const NODE_TOP = 34;
const portY = (node: any, portId: string, side: string) => {
  const def = NODE_DEFS[node.type]; if (!def) return 0;
  const ports = def.ports.filter((p: any) => side === "in" ? p.dir === PORT.IN : p.dir === PORT.OUT);
  const idx = ports.findIndex((p: any) => p.id === portId);
  return node.y + NODE_TOP + idx * PORT_H + PORT_H / 2;
};
const portX = (node: any, side: string) => side === "in" ? node.x : node.x + (node.w || 176);
const edgePath = (x1: number, y1: number, x2: number, y2: number) => {
  const dx = Math.abs(x2 - x1) * 0.55;
  return `M${x1},${y1} C${x1 + dx},${y1} ${x2 - dx},${y2} ${x2},${y2}`;
};
const fmtVal = (v: any) => {
  if (v === null || v === undefined) return "null";
  if (typeof v === "number") return Math.abs(v) < 1000 ? v.toFixed(2) : v.toFixed(0);
  if (typeof v === "object") return "{...}";
  return String(v).slice(0, 10);
};

export default function CanvasStudio() {
  const { sentimentResult } = useNexus();
  const [state, dispatch] = useReducer(reducer, INITIAL_STATE);
  const [computedVals, setComputedVals] = useState<Record<string, any>>({});
  const svgRef = useRef<SVGSVGElement>(null);
  const [drag, setDrag] = useState<any>(null);
  const [connLine, setConnLine] = useState<any>(null);
  const [hoverPort, setHoverPort] = useState<any>(null);
  const [selBox, setSelBox] = useState<any>(null);

  // Environment for compute - provides dashboard data to intelligence nodes
  const env = useMemo(() => ({
    sentiment: sentimentResult,
    t: 0,
  }), [sentimentResult]);

  useEffect(() => {
    const loop = () => {
      if (!state.paused) { 
        setComputedVals(computeGraph(state.nodes, state.edges, { ...env, t: Date.now() / 1000 })); 
      }
      requestAnimationFrame(loop);
    };
    const id = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(id);
  }, [state.nodes, state.edges, state.paused, env]);

  const toCanvas = useCallback((cx: number, cy: number) => {
    const rect = svgRef.current?.getBoundingClientRect(); if (!rect) return { x: 0, y: 0 };
    return { x: (cx - rect.left - state.pan.x) / state.zoom, y: (cy - rect.top - state.pan.y) / state.zoom };
  }, [state.pan, state.zoom]);

  useEffect(() => {
    if (!drag && !state.connecting && !selBox) return;
    const mv = (e: MouseEvent) => {
      if (drag?.k === "pan") { dispatch({ type: "VIEW", pan: { x: drag.ox + (e.clientX - drag.sx), y: drag.oy + (e.clientY - drag.sy) }, zoom: state.zoom }); }
      if (drag?.k === "nodes") {
        const dx = (e.clientX - drag.sx) / state.zoom, dy = (e.clientY - drag.sy) / state.zoom;
        dispatch({ type: "NODE_MOVE", dx, dy });
        setDrag((d: any) => ({ ...d, sx: e.clientX, sy: e.clientY }));
      }
      if (state.connecting) {
        const rect = svgRef.current?.getBoundingClientRect();
        if (rect) setConnLine({ x: (e.clientX - rect.left - state.pan.x) / state.zoom, y: (e.clientY - rect.top - state.pan.y) / state.zoom });
      }
      if (selBox) {
        const p = toCanvas(e.clientX, e.clientY);
        setSelBox((b: any) => ({ ...b, ex: p.x, ey: p.y }));
      }
    };
    const up = () => {
      if (selBox) {
        const minX = Math.min(selBox.sx, selBox.ex), maxX = Math.max(selBox.sx, selBox.ex);
        const minY = Math.min(selBox.sy, selBox.ey), maxY = Math.max(selBox.sy, selBox.ey);
        const ids = state.nodes.filter(n => (n.x || 0) < maxX && (n.x || 0) + (n.w || 176) > minX && (n.y || 0) < maxY && (n.y || 0) + 120 > minY).map(n => n.id);
        dispatch({ type: "SEL", ids }); setSelBox(null);
      }
      setDrag(null);
    };
    window.addEventListener("mousemove", mv); window.addEventListener("mouseup", up);
    return () => { window.removeEventListener("mousemove", mv); window.removeEventListener("mouseup", up); };
  }, [drag, state.connecting, selBox, state.zoom, state.pan, state.nodes, toCanvas]);

  const svgParts: string[] = [];
  state.nodes.forEach((n: any) => {
    const def = NODE_DEFS[n.type]; if (!def) return;
    const v = computedVals[n.id] || {};
    def.ports.filter((p: any) => p.type === TYPES.STRING && p.dir === PORT.OUT).forEach((p: any) => {
      if (!state.edges.some(e => e.from === n.id && e.fromPort === p.id) && v[p.id]) { svgParts.push(v[p.id]); }
    });
  });

  return (
    <div className="flex w-full h-[700px] bg-[#050505] border border-white/10 rounded-3xl overflow-hidden font-sans antialiased">
      <div className="w-[280px] border-r border-white/5 flex flex-col bg-[#0A0A0A]">
        <div className="flex p-4 border-b border-white/5 gap-2">
           <button onClick={() => dispatch({type:"SIDEBAR", v:"nodes"})} className={`flex-1 py-1 px-3 text-[10px] font-bold uppercase rounded-md transition-colors ${state.sidebar === 'nodes' ? 'bg-white/10 text-white' : 'text-white/30 hover:text-white/60'}`}>Nodes</button>
           <button onClick={() => dispatch({type:"SIDEBAR", v:"inspect"})} className={`flex-1 py-1 px-3 text-[10px] font-bold uppercase rounded-md transition-colors ${state.sidebar === 'inspect' ? 'bg-white/10 text-white' : 'text-white/30 hover:text-white/60'}`}>Inspect</button>
        </div>
        <div className="flex-1 overflow-y-auto custom-scrollbar p-4">
           {state.sidebar === 'nodes' ? (
             <div className="space-y-6">
                {Object.entries(NODE_DEFS).reduce((acc: any, [k, d]: any) => {
                  if(!acc[d.cat]) acc[d.cat] = [];
                  acc[d.cat].push([k, d]);
                  return acc;
                }, {}).map(([cat, items]: any) => (
                  <div key={cat} className="space-y-3">
                     <span className="text-[9px] font-black uppercase tracking-widest text-[#52525B]">{cat}</span>
                     <div className="grid grid-cols-2 gap-2">
                        {items.map(([k, d]: any) => (
                          <button key={k} onClick={() => dispatch({type:"NODE_ADD", node: newNode(k, 100, 100)})}
                            title={d.description}
                            className="p-3 bg-[#161616] border border-white/5 rounded-xl hover:bg-white/5 transition-colors flex flex-col items-center gap-1 group relative">
                             <span className="text-xl">{d.icon}</span>
                             <span className="text-[9px] font-medium text-white/50">{d.label}</span>
                             <div className="absolute bottom-full left-0 mb-2 w-48 p-2 bg-black border border-white/10 rounded-lg text-[8px] text-white/70 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-50 shadow-2xl">
                                {d.description}
                             </div>
                          </button>
                        ))}
                     </div>
                  </div>
                ))}
             </div>
           ) : (
             <div className="space-y-6">
                {state.selNodes.length > 0 ? (
                  state.selNodes.map(id => {
                    const node = state.nodes.find(n => n.id === id) as any;
                    if(!node) return null;
                    const def = NODE_DEFS[node.type];
                    const { valid, errors } = validateNode(node, state.edges);
                    return (
                      <div key={id} className="space-y-4">
                         <div className="flex items-center gap-2">
                            <span className="text-xl">{def.icon}</span>
                            <div>
                               <div className="text-[10px] font-bold text-white leading-tight">{node.customLabel || def.label}</div>
                               <div className="text-[8px] text-white/40 font-mono">{node.id}</div>
                            </div>
                         </div>
                         <div className="p-3 bg-black/50 border border-white/5 rounded-xl space-y-2">
                            <div className="text-[9px] font-bold text-white/20 uppercase tracking-tighter">Status</div>
                            <div className={`text-[10px] flex items-center gap-2 ${valid ? 'text-emerald-500' : 'text-red-500'}`}>
                               <div className={`w-1.5 h-1.5 rounded-full ${valid ? 'bg-emerald-500' : 'bg-red-500 animate-pulse'}`} />
                               {valid ? "Operational" : "Configuration Error"}
                            </div>
                            {!valid && errors.map((err, i) => (
                               <div key={i} className="text-[9px] text-red-500/70 border-l border-red-500/30 pl-2 py-0.5">{err}</div>
                            ))}
                         </div>
                         <div className="p-3 bg-black/50 border border-white/5 rounded-xl space-y-3">
                            <div className="text-[9px] font-bold text-white/20 uppercase tracking-tighter">Properties</div>
                            <div className="space-y-2">
                               <label className="block space-y-1">
                                  <span className="text-[9px] text-white/40">Label</span>
                                  <input value={node.customLabel} 
                                    onChange={(e) => dispatch({type:"NODE_UPD", id: node.id, p: {customLabel: e.target.value}})}
                                    className="w-full bg-[#161616] border border-white/10 rounded px-2 py-1 text-[10px] text-white outline-none focus:border-white/20" />
                               </label>
                            </div>
                         </div>
                      </div>
                    );
                  })
                ) : state.selEdge ? (
                   (() => {
                      const edge = state.edges.find(e => e.id === state.selEdge);
                      if(!edge) return null;
                      return (
                        <div className="space-y-4">
                           <div className="text-[10px] font-bold text-white uppercase tracking-widest">Edge Properties</div>
                           <div className="p-3 bg-black/50 border border-white/5 rounded-xl space-y-3">
                              <label className="block space-y-1">
                                 <span className="text-[9px] text-white/40">Edge Label</span>
                                 <input value={edge.label} autoFocus
                                   onChange={(e) => dispatch({type:"EDGE_UPD", id: edge.id, p: {label: e.target.value}})}
                                   className="w-full bg-[#161616] border border-white/10 rounded px-2 py-1 text-[10px] text-white outline-none focus:border-white/20" />
                              </label>
                              <button onClick={() => dispatch({type:"EDGE_DEL", id: edge.id})}
                                className="w-full py-2 bg-red-500/10 hover:bg-red-500/20 text-red-500 text-[10px] rounded-lg border border-red-500/20 transition-colors">
                                 Delete Connection
                              </button>
                           </div>
                        </div>
                      )
                   })()
                ) : (
                  <div className="text-white/30 text-xs italic text-center pt-10 font-mono">Select a node or edge to inspect...</div>
                )}
             </div>
           )}
        </div>
      </div>

      <div className="flex-1 relative bg-black overflow-hidden group">
         <div className="absolute inset-x-0 top-0 p-4 flex items-center justify-between z-10 pointer-events-none">
            <div className="flex items-center gap-2 pointer-events-auto">
                <button onClick={() => dispatch({type:"UNDO"})} className="p-2 bg-black/40 border border-white/5 rounded-lg hover:bg-white/10 text-white/40"><Undo2 size={14}/></button>
                <button onClick={() => dispatch({type:"REDO"})} className="p-2 bg-black/40 border border-white/5 rounded-lg hover:bg-white/10 text-white/40"><Redo2 size={14}/></button>
                <div className="w-[1px] h-4 bg-white/5 mx-1" />
                <button onClick={() => dispatch({type:"GRID"})} className={`p-2 bg-black/40 border border-white/5 rounded-lg hover:bg-white/10 ${state.grid ? 'text-white' : 'text-white/40'}`}><Grid size={14}/></button>
                <button onClick={() => dispatch({type:"PAUSE"})} className={`p-2 bg-black/40 border border-white/5 rounded-lg hover:bg-white/10 ${!state.paused ? 'text-emerald-500' : 'text-white/40'}`}>{!state.paused ? <Pause size={14}/> : <Play size={14}/>}</button>
            </div>
            <div className="flex items-center bg-black/40 border border-white/5 rounded-lg p-1 gap-2 pointer-events-auto">
                <span className="text-[10px] font-mono text-white/30 px-2">{Math.round(state.zoom * 100)}%</span>
            </div>
         </div>

         <svg ref={svgRef} className="w-full h-full cursor-crosshair"
           onMouseDown={(e) => {
             if(e.button === 0) {
                const p = toCanvas(e.clientX, e.clientY);
                setSelBox({sx:p.x, sy:p.y, ex:p.x, ey:p.y});
                dispatch({type:"SEL", ids:[]});
             }
           }}
           onWheel={(e) => {
              const nz = Math.max(0.1, state.zoom * (e.deltaY > 0 ? 0.9 : 1.1));
              dispatch({type:"VIEW", pan: state.pan, zoom: nz});
           }}>
           <defs>
              <pattern id="gridLarge" width={100 * state.zoom} height={100 * state.zoom} patternUnits="userSpaceOnUse" x={state.pan.x % (100 * state.zoom)} y={state.pan.y % (100 * state.zoom)}>
                 <path d={`M ${100 * state.zoom} 0 L 0 0 0 ${100 * state.zoom}`} fill="none" stroke="rgba(255,255,255,0.03)" strokeWidth="1"/>
              </pattern>
           </defs>
           {state.grid && <rect width="100%" height="100%" fill="url(#gridLarge)" />}

            <g transform={`translate(${state.pan.x}, ${state.pan.y}) scale(${state.zoom})`}>
              {state.edges.map((e: any) => {
                 const fromN = state.nodes.find(n => n.id === e.from);
                 const toN = state.nodes.find(n => n.id === e.to);
                 if(!fromN || !toN) return null;
                 const x1 = portX(fromN, "out"), y1 = portY(fromN, e.fromPort, "out");
                 const x2 = portX(toN, "in"), y2 = portY(toN, e.toPort, "in");
                 const isSel = state.selEdge === e.id;
                 const midX = (x1 + x2) / 2, midY = (y1 + y2) / 2;
                 return (
                   <g key={e.id} onClick={() => dispatch({type:"SEL", ids:[], edge: e.id})}>
                      <path d={edgePath(x1, y1, x2, y2)} fill="none" stroke={isSel ? T.white : T.purple} strokeWidth={isSel ? 3 : 2} opacity={isSel ? 1 : 0.6} className="cursor-pointer transition-all hover:opacity-100" />
                      {e.label && (
                        <g transform={`translate(${midX}, ${midY})`}>
                           <rect x={-20} y={-10} width={40} height={20} rx={4} fill={T.bg} stroke={T.line} strokeWidth={1} />
                           <text textAnchor="middle" dominantBaseline="middle" fill={T.textSub} fontSize={9} className="font-mono">{e.label}</text>
                        </g>
                      )}
                   </g>
                 );
              })}

              {state.connecting && connLine && (
                <path d={edgePath(portX(state.nodes.find(n => n.id === state.connecting.fromNode), "out"), portY(state.nodes.find(n => n.id === state.connecting.fromNode), state.connecting.fromPort, "out"), connLine.x, connLine.y)} fill="none" stroke={T.white} strokeWidth={1} strokeDasharray="4,4" />
              )}

              {state.nodes.map((n: any) => {
                 const isSel = state.selNodes.includes(n.id);
                 const isEditing = state.editingNode === n.id;
                 const def = NODE_DEFS[n.type];
                 const { valid, errors } = validateNode(n, state.edges);
                 return (
                   <g key={n.id} transform={`translate(${n.x}, ${n.y})`} 
                     onMouseDown={(e) => {
                       e.stopPropagation(); dispatch({type:"SEL", ids:[n.id]});
                       setDrag({k:"nodes", sx:e.clientX, sy:e.clientY});
                     }}
                     onDoubleClick={(e) => {
                       e.stopPropagation(); dispatch({type:"NODE_EDIT_START", id: n.id});
                     }}>
                      <rect width={n.w || 176} height={def.ports.length * 24 + 40} rx={16} 
                        fill="#111" 
                        stroke={!valid ? T.red : (isSel ? def.color : "rgba(255,255,255,0.1)")} 
                        strokeWidth={isSel || !valid ? 2 : 1}
                        className="transition-all" />
                      <g transform="translate(12, 22)">
                        <text fill={def.color} className="font-mono text-[10px] font-bold">{def.icon}</text>
                        {isEditing ? (
                          <foreignObject x={20} y={-12} width={120} height={20}>
                             <input autoFocus value={n.customLabel} 
                               className="w-full bg-black/50 border border-white/20 text-[10px] text-white outline-none rounded px-1"
                               onChange={(e) => dispatch({type:"NODE_UPD", id: n.id, p: {customLabel: e.target.value}})}
                               onBlur={() => dispatch({type:"NODE_EDIT_END"})}
                               onKeyDown={(e) => e.key === 'Enter' && dispatch({type:"NODE_EDIT_END"})} />
                          </foreignObject>
                        ) : (
                          <text x={20} y={0} fill={isSel ? T.white : "rgba(255,255,255,0.8)"} className="font-sans text-[10px] font-semibold">{n.customLabel || def.label}</text>
                        )}
                      </g>
                      {!valid && <circle cx={(n.w || 176) - 12} cy={22} r={4} fill={T.red} />}
                      {def.ports.map((p: any, i: number) => {
                         const py = 40 + i * 24;
                         const isOut = p.dir === PORT.OUT;
                         const isConnecting = !!state.connecting;
                         const isCompatible = isConnecting && !isOut && (state.connecting.portType === TYPES.ANY || p.type === TYPES.ANY || state.connecting.portType === p.type);
                         const isSource = isConnecting && state.connecting.fromNode === n.id && state.connecting.fromPort === p.id;
                         
                         return (
                           <g key={p.id} onMouseDown={(e) => {
                             e.stopPropagation();
                             if(isOut) dispatch({type:"CONNECT", data: {fromNode: n.id, fromPort: p.id, portType: p.type}});
                             else if(state.connecting) {
                                if(isCompatible) dispatch({type:"EDGE_ADD", edge: {id:`e_${Date.now()}`, from: state.connecting.fromNode, fromPort: state.connecting.fromPort, to: n.id, toPort: p.id}});
                                else console.warn("Incompatible port types");
                             }
                           }}>
                              <circle cx={isOut ? (n.w || 176) : 0} cy={py} r={isCompatible ? 8 : 6} 
                                fill={PORT_COLORS[p.type]} 
                                opacity={isConnecting && !isCompatible && !isSource ? 0.2 : 1}
                                stroke={isCompatible ? T.white : "none"} strokeWidth={2}
                                className="transition-all cursor-pointer hover:scale-125" />
                              <text x={isOut ? (n.w || 176) - 12 : 12} y={py + 4} textAnchor={isOut ? "end" : "start"} 
                                fill={isCompatible ? T.white : "rgba(255,255,255,0.4)"} 
                                className="text-[9px] pointer-events-none transition-colors">{p.label}</text>
                           </g>
                         );
                      })}
                   </g>
                 );
              })}

              {selBox && (
                <rect x={Math.min(selBox.sx, selBox.ex)} y={Math.min(selBox.sy, selBox.ey)} width={Math.abs(selBox.ex - selBox.sx)} height={Math.abs(selBox.ey - selBox.sy)} fill="rgba(139,92,246,0.05)" stroke={T.purple} strokeWidth={1} strokeDasharray="4,4" />
              )}
           </g>
         </svg>
      </div>

      <div className="w-[320px] bg-[#0A0A0A] border-l border-white/5 flex flex-col">
         <div className="p-4 border-b border-white/5 flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-widest text-white/40">Visualizer</span>
            <Maximize size={12} className="text-white/20"/>
         </div>
         <div className="flex-1 bg-black p-6 flex items-center justify-center relative overflow-hidden">
             <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
             <svg width="100%" height="100%" viewBox="0 0 400 400" className="drop-shadow-[0_0_40px_rgba(139,92,246,0.2)]"
               dangerouslySetInnerHTML={{__html: svgParts.join("")}} />
         </div>
         <div className="p-4 border-t border-white/5 space-y-4">
            <div className="flex items-center justify-between">
                <span className="text-[9px] font-mono text-white/20 uppercase">System Logs</span>
                <span className="text-[9px] font-mono text-emerald-500">STABLE</span>
            </div>
            <div className="bg-black border border-white/5 rounded-xl p-3 h-24 overflow-y-auto custom-scrollbar font-mono text-[9px] text-white/30 space-y-1">
               <div>[00:00:01] Nexus Core Initialized</div>
               <div>[00:00:02] SVG Render context ready</div>
               {state.nodes.map(n => <div key={n.id} className="text-violet-500">Node {n.id} mounted...</div>)}
            </div>
         </div>
      </div>
    </div>
  );
}
