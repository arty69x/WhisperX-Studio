'use client';

import React from 'react';
import { ExecutiveSummary as SummaryType } from '@/lib/types';
import { motion } from 'motion/react';
import { Lightbulb, TrendingUp, AlertCircle, Calendar } from 'lucide-react';

interface Props {
  summary: SummaryType;
}

export default function ExecutiveSummary({ summary }: Props) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <motion.div 
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="md:col-span-2 space-y-6"
      >
        <div className="bg-[#0A0A0A] p-8 rounded-2xl border border-white/10 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
            <TrendingUp size={120} />
          </div>
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-4">
               <div className="w-8 h-[1px] bg-emerald-500" />
               <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-emerald-500">AI Synthesized Report</span>
            </div>
            <h2 className="font-display text-4xl font-bold leading-tight mb-4">{summary.headline}</h2>
            <div className="flex items-center gap-4 text-white/50 text-xs font-mono">
                <span className="flex items-center gap-1"><Calendar size={12}/> {summary.analysisDate}</span>
                <span className="w-1 h-1 rounded-full bg-white/20" />
                <span>NEXUS-V2 ANALYTICS</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {summary.topActionables.map((item, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 * idx }}
              className="bg-[#0D0D0D] p-5 rounded-xl border border-white/5 hover:border-white/20 transition-colors"
            >
              <div className="flex items-center justify-between mb-3">
                <Lightbulb size={20} className="text-amber-400" />
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                  item.impact === 'High' ? 'bg-rose-500/10 text-rose-500' : 
                  item.impact === 'Medium' ? 'bg-blue-500/10 text-blue-500' : 'bg-slate-500/10 text-slate-500'
                }`}>
                  {item.impact} Impact
                </span>
              </div>
              <h4 className="font-display font-bold text-sm mb-2">{item.title}</h4>
              <p className="text-white/40 text-xs leading-relaxed">{item.description}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="bg-[#0A0A0A] p-8 rounded-2xl border border-white/10 flex flex-col items-center justify-center text-center space-y-6"
      >
        <span className="text-xs uppercase tracking-widest text-white/40 font-mono italic font-light">Global Sentiment Index</span>
        <div className="relative">
             <div className="absolute inset-0 blur-3xl opacity-20 bg-emerald-500" />
             <div className="text-8xl font-display font-black tracking-tighter relative z-10">
                {Math.round(summary.overallSentiment * 100)}%
             </div>
        </div>
        <p className="text-sm text-white/50 max-w-[200px]">
           Aggregated polarity across all detected fragments in the current batch.
        </p>
        <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
            <div 
                className="h-full bg-emerald-500 shadow-[0_0_10px_#10b981]" 
                style={{ width: `${(summary.overallSentiment + 1) / 2 * 100}%` }}
            />
        </div>
      </motion.div>
    </div>
  );
}
