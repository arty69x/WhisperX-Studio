'use client';

import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import cloud from 'd3-cloud';
import { WordCloudItem } from '@/lib/types';
import { motion } from 'motion/react';

interface Props {
  words: WordCloudItem[];
}

export default function WordCloud({ words }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current || !words.length) return;

    const width = containerRef.current.clientWidth;
    const height = 400;

    // Clear previous SVG
    d3.select(containerRef.current).select('svg').remove();

    const layout = cloud()
      .size([width, height])
      .words(words.map(d => ({ 
        text: d.text, 
        size: 10 + d.size * 5, 
        sentiment: d.sentiment 
      })))
      .padding(5)
      .rotate(() => (Math.random() > 0.5 ? 0 : 90))
      .font("Space Grotesk")
      .fontSize((d: any) => d.size)
      .on("end", draw);

    layout.start();

    function draw(words: any[]) {
      const svg = d3.select(containerRef.current)
        .append("svg")
        .attr("width", layout.size()[0])
        .attr("height", layout.size()[1])
        .append("g")
        .attr("transform", "translate(" + layout.size()[0] / 2 + "," + layout.size()[1] / 2 + ")");

      svg.selectAll("text")
        .data(words)
        .enter().append("text")
        .style("font-size", d => d.size + "px")
        .style("font-family", "Space Grotesk")
        .style("font-weight", "600")
        .style("fill", (d: any) => {
           if (d.sentiment === 'positive') return '#10B981'; // Nexus Emerald
           if (d.sentiment === 'negative') return '#F43F5E'; // Nexus Rose/Red
           return '#52525B'; // Nexus Zinc/Slate
        })
        .attr("text-anchor", "middle")
        .attr("transform", d => "translate(" + [d.x, d.y] + ")rotate(" + d.rotate + ")")
        .text(d => d.text)
        .style("cursor", "default")
        .append("title")
        .text(d => `Relevance: ${d.size}`);
    }
  }, [words]);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="w-full h-[400px] bg-[#0A0A0A] rounded-2xl border border-white/10 overflow-hidden"
      ref={containerRef}
    />
  );
}
