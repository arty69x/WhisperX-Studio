'use client';

import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts';
import { SentimentPoint } from '@/lib/types';
import { motion } from 'motion/react';

interface Props {
  data: SentimentPoint[];
}

export default function TrendChart({ data }: Props) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full h-[400px] bg-[#0A0A0A] p-6 rounded-2xl border border-white/10"
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-display text-xs uppercase tracking-widest text-white/50">Sentiment Velocity</h3>
        <div className="flex gap-4">
            <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-emerald-500" />
                <span className="text-[10px] uppercase tracking-tighter text-white/30">Positivity</span>
            </div>
        </div>
      </div>
      <ResponsiveContainer width="100%" height="90%">
        <AreaChart data={data}>
          <defs>
            <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
              <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" vertical={false} />
          <XAxis 
            dataKey="date" 
            stroke="#ffffff30" 
            fontSize={10} 
            tickLine={false} 
            axisLine={false} 
          />
          <YAxis 
            stroke="#ffffff30" 
            fontSize={10} 
            tickLine={false} 
            axisLine={false}
            domain={[-1, 1]}
            ticks={[-1, -0.5, 0, 0.5, 1]}
          />
          <Tooltip 
            contentStyle={{ 
                backgroundColor: '#0A0A0A', 
                border: '1px solid #ffffff20',
                borderRadius: '8px',
                fontSize: '12px',
                color: '#fff'
            }} 
            itemStyle={{ color: '#fff' }}
            cursor={{ stroke: '#ffffff10', strokeWidth: 1 }}
          />
          <Area 
            type="monotone" 
            dataKey="score" 
            stroke="#10b981" 
            strokeWidth={3}
            fillOpacity={1} 
            fill="url(#colorScore)"
            animationDuration={1500}
          />
        </AreaChart>
      </ResponsiveContainer>
    </motion.div>
  );
}
