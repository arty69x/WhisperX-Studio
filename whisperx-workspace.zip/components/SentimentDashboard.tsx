'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { analyzeSentiment } from '@/lib/gemini';
import { SentimentAnalysisResult } from '@/lib/types';
import WordCloud from './WordCloud';
import TrendChart from './TrendChart';
import ExecutiveSummary from './ExecutiveSummary';
import CanvasStudio from './CanvasStudio';
import { Sparkles, Terminal, BookOpen, BarChart3, Cloud, Loader2, ArrowRight, Layers, Trash2 } from 'lucide-react';
import { useNexus } from '@/lib/nexus-context';

export default function SentimentDashboard() {
  const { sentimentResult: result, setSentimentResult: setResult, isAnalyzing, setIsAnalyzing } = useNexus();
  const [inputText, setInputText] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'report' | 'forge'>('report');

  const handleAnalyze = async () => {
    if (!inputText.trim()) return;
    setIsAnalyzing(true);
    setError(null);
    try {
      const data = await analyzeSentiment(inputText);
      setResult(data);
      setActiveTab('report');
    } catch (err) {
      console.error(err);
      setError("AI Synthesis failed. Check the console or your API key configuration.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const reset = () => {
    setResult(null);
    setInputText('');
    setActiveTab('report');
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-12 space-y-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 py-10 border-b border-white/10">
        <div className="space-y-4">
            <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-violet-500 animate-pulse" />
                <span className="text-[10px] font-mono tracking-[0.4em] uppercase text-white/40">Nexus-V3 Sentiment Core</span>
            </div>
            <h1 className="font-display text-7xl font-bold tracking-tighter uppercase leading-[0.8] mb-4">
                Sentiment <br />
                <span className="text-violet-500 italic font-medium serif">Nexus</span>
            </h1>
            <p className="text-white/40 max-w-md font-sans text-sm leading-relaxed">
               Advanced NLP engine for high-precision extraction of kinetic consumer feedback fragments. Recursive synthesis for actionable business intelligence.
            </p>
        </div>
        
        {!result && (
            <div className="space-y-2 text-right">
                <span className="text-[10px] font-mono text-white/20 uppercase">System Status</span>
                <div className="flex bg-white/5 border border-white/10 px-4 py-2 rounded-lg gap-6 text-xs font-mono">
                    <span className="flex items-center gap-1 text-emerald-500"><div className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> ONLINE</span>
                    <span className="text-white/20">|</span>
                    <span className="text-white/40">LATENCY: 24ms</span>
                </div>
            </div>
        )}

        {result && (
          <div className="flex flex-col items-end gap-2">
            <div className="flex bg-white/5 p-1 rounded-xl border border-white/10">
              <button 
                onClick={() => setActiveTab('report')}
                className={`px-4 py-2 rounded-lg text-xs font-bold uppercase transition-all ${activeTab === 'report' ? 'bg-white text-black shadow-lg shadow-white/10' : 'text-white/40 hover:text-white'}`}
              >
                Synthesized Report
              </button>
              <button 
                onClick={() => setActiveTab('forge')}
                className={`px-4 py-2 rounded-lg text-xs font-bold uppercase transition-all flex items-center gap-2 ${activeTab === 'forge' ? 'bg-violet-600 text-white shadow-lg shadow-violet-500/20' : 'text-white/40 hover:text-white'}`}
              >
                <Layers size={14} />
                Visual Forge
              </button>
            </div>
            {activeTab === 'forge' && (
              <span className="text-[9px] font-mono text-emerald-500/60 uppercase tracking-widest animate-pulse">
                Dash Data Linked: Intelligence Nodes Active
              </span>
            )}
          </div>
        )}
      </div>

      <AnimatePresence mode="wait">
        {!result ? (
          <motion.div 
            key="input"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            className="space-y-8"
          >
            <div className="bg-[#0A0A0A] border border-white/10 rounded-[32px] p-8 shadow-2xl relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none transition-opacity group-focus-within:opacity-10">
                 <Terminal size={240} />
              </div>
              <label 
                htmlFor="feedback-input" 
                className="block text-xs font-mono uppercase tracking-[0.3em] text-white/30 mb-6"
              >
                {/* Feed Raw Fragment Data */}
              </label>
              <textarea
                id="feedback-input"
                suppressHydrationWarning
                className="w-full h-80 bg-transparent border-none text-xl font-sans text-white/80 placeholder:text-white/10 focus:ring-0 resize-none outline-none custom-scrollbar"
                placeholder="Paste your raw customer reviews here. AI will extract word frequency, sentiment trajectory, and executive action points..."
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
              />
              <div className="flex items-center justify-between mt-8">
                <div className="flex items-center gap-4 text-white/20 text-[10px] font-mono">
                    <span className="flex items-center gap-1"><BookOpen size={12}/> Supported: Multi-Batch</span>
                    <span className="flex items-center gap-1"><Cloud size={12}/> Secure: Local Key</span>
                </div>
                <button
                  onClick={handleAnalyze}
                  disabled={isAnalyzing || !inputText.trim()}
                  className="group relative px-10 py-4 bg-white text-black font-display font-black rounded-full overflow-hidden transition-all hover:scale-105 active:scale-95 disabled:opacity-30 disabled:hover:scale-100"
                >
                  <div className="absolute inset-0 bg-violet-500 translate-x-full group-hover:translate-x-0 transition-transform duration-500" />
                  <span className="relative z-10 flex items-center gap-2 group-hover:text-white transition-colors uppercase italic tracking-tighter">
                    {isAnalyzing ? (
                        <Loader2 className="animate-spin" size={20} />
                    ) : (
                        <Sparkles size={20} />
                    )}
                    {isAnalyzing ? 'Processing Synthesis...' : 'Initiate Analysis'}
                  </span>
                </button>
              </div>
            </div>
            {error && (
                <div className="bg-rose-500/10 border border-rose-500/20 p-4 rounded-xl flex items-center gap-3 text-rose-500 text-sm">
                    <Loader2 size={16} /> {error}
                </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 opacity-30">
                 {['Frequency Clustering', 'Temporal Flow', 'Actionable Insights'].map(t => (
                     <div key={t} className="p-6 border border-white/10 rounded-2xl flex items-center justify-between font-display text-xs uppercase tracking-widest italic">
                         <span>{t}</span>
                         <div className="w-1.5 h-1.5 rounded-full bg-white/40" />
                     </div>
                 ))}
            </div>
          </motion.div>
        ) : (
          <motion.div 
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="space-y-12"
          >
             <div className="flex items-center justify-between">
                <button 
                    onClick={reset}
                    className="text-xs font-mono text-white/40 hover:text-white transition-colors flex items-center gap-2 group"
                >
                    <ArrowRight size={14} className="rotate-180 group-hover:-translate-x-1 transition-transform" /> Back to Terminal
                </button>
                <div className="flex shrink-0">
                     <div className="px-3 py-1 bg-violet-500/10 border border-violet-500/30 rounded-full text-[10px] font-bold text-violet-500 uppercase">
                        AI Confidence: 98.4%
                     </div>
                </div>
             </div>

             {activeTab === 'report' ? (
               <div className="space-y-12 h-auto">
                 <ExecutiveSummary summary={result.summary} />

                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div className="space-y-4">
                       <div className="flex items-center gap-2">
                            <BarChart3 size={16} className="text-white/40" />
                            <h4 className="font-display text-xs uppercase tracking-widest text-white/60">Fragment Trajectory</h4>
                       </div>
                       <TrendChart data={result.trend} />
                    </div>
                    <div className="space-y-4">
                       <div className="flex items-center gap-2">
                            <Cloud size={16} className="text-white/40" />
                            <h4 className="font-display text-xs uppercase tracking-widest text-white/60">Semantic Word Cloud</h4>
                       </div>
                       <WordCloud words={result.wordCloud} />
                    </div>
                 </div>
               </div>
             ) : (
               <div className="animate-in fade-in slide-in-from-bottom-4 h-full">
                  <CanvasStudio />
               </div>
             )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

