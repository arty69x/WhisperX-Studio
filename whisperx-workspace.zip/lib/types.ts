export interface SentimentPoint {
  date: string;
  score: number; // -1 to 1
  label: string;
}

export interface WordCloudItem {
  text: string;
  size: number;
  sentiment: 'positive' | 'negative' | 'neutral';
}

export interface ExecutiveSummary {
  headline: string;
  topActionables: {
    title: string;
    description: string;
    impact: 'High' | 'Medium' | 'Low';
  }[];
  overallSentiment: number;
  analysisDate: string;
}

export interface SentimentAnalysisResult {
  trend: SentimentPoint[];
  wordCloud: WordCloudItem[];
  summary: ExecutiveSummary;
}
