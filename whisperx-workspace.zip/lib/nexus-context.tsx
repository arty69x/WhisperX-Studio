'use client';

import React, { createContext, useContext, useState, ReactNode } from 'react';
import { SentimentAnalysisResult } from './types';

interface NexusContextType {
  sentimentResult: SentimentAnalysisResult | null;
  setSentimentResult: (result: SentimentAnalysisResult | null) => void;
  isAnalyzing: boolean;
  setIsAnalyzing: (val: boolean) => void;
}

const NexusContext = createContext<NexusContextType | undefined>(undefined);

export function NexusProvider({ children }: { children: ReactNode }) {
  const [sentimentResult, setSentimentResult] = useState<SentimentAnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  return (
    <NexusContext.Provider value={{ sentimentResult, setSentimentResult, isAnalyzing, setIsAnalyzing }}>
      {children}
    </NexusContext.Provider>
  );
}

export function useNexus() {
  const context = useContext(NexusContext);
  if (context === undefined) {
    throw new Error('useNexus must be used within a NexusProvider');
  }
  return context;
}
