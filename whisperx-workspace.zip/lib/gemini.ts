import { GoogleGenAI, Type } from "@google/genai";
import { SentimentAnalysisResult } from "./types";

export async function analyzeSentiment(rawText: string): Promise<SentimentAnalysisResult> {
  const apiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("NEXT_PUBLIC_GEMINI_API_KEY is not configured.");
  }

  const ai = new GoogleGenAI({ apiKey });

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analyze the following batch of customer reviews and provide a structured JSON report. 
    1. Extract a sentiment trend (sequence of scores from -1 to 1) assuming a time-series if dates are present, or just a logical sequence of 10 points.
    2. Identify the top 20 keywords for a word cloud, specifying their frequency (size) and whether they are positive, negative, or neutral.
    3. Write an executive summary with a strong headline and 3 specific actionable improvement areas.

    REVIEWS:
    ${rawText}
    `,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        required: ["trend", "wordCloud", "summary"],
        properties: {
          trend: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              required: ["date", "score", "label"],
              properties: {
                date: { type: Type.STRING },
                score: { type: Type.NUMBER },
                label: { type: Type.STRING }
              }
            }
          },
          wordCloud: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              required: ["text", "size", "sentiment"],
              properties: {
                text: { type: Type.STRING },
                size: { type: Type.NUMBER },
                sentiment: { 
                  type: Type.STRING,
                  enum: ["positive", "negative", "neutral"]
                }
              }
            }
          },
          summary: {
            type: Type.OBJECT,
            required: ["headline", "topActionables", "overallSentiment", "analysisDate"],
            properties: {
              headline: { type: Type.STRING },
              analysisDate: { type: Type.STRING },
              overallSentiment: { type: Type.NUMBER },
              topActionables: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  required: ["title", "description", "impact"],
                  properties: {
                    title: { type: Type.STRING },
                    description: { type: Type.STRING },
                    impact: { 
                      type: Type.STRING,
                      enum: ["High", "Medium", "Low"]
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  });

  if (!response.text) {
    throw new Error("No response from AI");
  }

  return JSON.parse(response.text) as SentimentAnalysisResult;
}
